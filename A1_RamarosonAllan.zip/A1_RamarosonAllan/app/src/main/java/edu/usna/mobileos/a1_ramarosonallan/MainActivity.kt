package edu.usna.mobileos.a1_ramarosonallan

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var topTextView: TextView
    lateinit var ac : Button
    lateinit var plusmin : Button
    lateinit var div : Button
    lateinit var percent : Button
    lateinit var seven : Button
    lateinit var eight : Button
    lateinit var nine : Button
    lateinit var mult : Button
    lateinit var four : Button
    lateinit var five : Button
    lateinit var six : Button
    lateinit var minus : Button
    lateinit var one : Button
    lateinit var two : Button
    lateinit var three : Button
    lateinit var plus : Button
    lateinit var zero : Button
    lateinit var decimal : Button
    lateinit var equal : Button
    lateinit var par : Button
    lateinit var rpar : Button
    lateinit var mc : Button
    lateinit var mp : Button
    lateinit var mm : Button
    lateinit var mr : Button
    lateinit var second : Button
    lateinit var x2: Button
    lateinit var x3: Button
    lateinit var xy: Button
    lateinit var ex: Button
    lateinit var tenx: Button
    lateinit var x1: Button
    lateinit var rt2: Button
    lateinit var rt3: Button
    lateinit var rty: Button
    lateinit var ln : Button
    lateinit var log : Button
    lateinit var xclam : Button
    lateinit var sin : Button
    lateinit var cos : Button
    lateinit var tan : Button
    lateinit var e : Button
    lateinit var ee : Button
    lateinit var rad : Button
    lateinit var sinh : Button
    lateinit var cosh : Button
    lateinit var tanh : Button
    lateinit var pi : Button
    lateinit var rand : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        topTextView = findViewById(R.id.TopText)

        // buttons
        ac = findViewById(R.id.AC)
        plusmin = findViewById(R.id.PlusMinus)
        percent = findViewById(R.id.PercentSign)
        div = findViewById(R.id.Divide)
        seven = findViewById(R.id.Seven)
        eight  = findViewById(R.id.Eight)
        nine = findViewById(R.id.Nine)
        mult = findViewById(R.id.Multiply)
        four = findViewById(R.id.Four)
        five = findViewById(R.id.Five)
        six = findViewById(R.id.Six)
        minus = findViewById(R.id.Minus)
        one = findViewById(R.id.One)
        two = findViewById(R.id.Two)
        three = findViewById(R.id.Three)
        plus = findViewById(R.id.Plus)
        zero = findViewById(R.id.Zero)
        decimal = findViewById(R.id.Decimal)
        equal = findViewById(R.id.Equal)

        if(resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE){
            par = findViewById(R.id.par)
            rpar = findViewById(R.id.rpar)
            mc = findViewById(R.id.mc)
            mp = findViewById(R.id.mp)
            mm = findViewById(R.id.mm)
            mr = findViewById(R.id.mr)
            ln = findViewById(R.id.ln)
            xclam = findViewById(R.id.xclam)
            sin = findViewById(R.id.sin)
            cos = findViewById(R.id.cos)
            tan = findViewById(R.id.tan)
            e = findViewById(R.id.e)
            ee = findViewById(R.id.EE)
            rad = findViewById(R.id.Rad)
            sinh = findViewById(R.id.sinh)
            cosh = findViewById(R.id.cosh)
            tanh = findViewById(R.id.tanh)
            rand = findViewById(R.id.rand)
            second = findViewById(R.id.second)
            x2 = findViewById(R.id.x2)
            x3 = findViewById(R.id.x3)
            xy = findViewById(R.id.xy)
            ex = findViewById(R.id.ex)
            tenx = findViewById(R.id.x10)
            x1 = findViewById(R.id.x1)
            rt2 = findViewById(R.id.rt2)
            rt3 = findViewById(R.id.rt3)
            rty = findViewById(R.id.rty)
            log = findViewById(R.id.log10)
            pi = findViewById(R.id.pi)

            par.setOnClickListener(this)
            mc.setOnClickListener(this)
            mp.setOnClickListener(this)
            mm.setOnClickListener(this)
            mr.setOnClickListener(this)
            ln.setOnClickListener(this)
            xclam.setOnClickListener(this)
            sin.setOnClickListener(this)
            cos.setOnClickListener(this)
            tan.setOnClickListener(this)
            e.setOnClickListener(this)
            ee.setOnClickListener(this)
            rad.setOnClickListener(this)
            sinh.setOnClickListener(this)
            cosh.setOnClickListener(this)
            tanh.setOnClickListener(this)
            rand.setOnClickListener(this)
            second.setOnClickListener(this)
            x2.setOnClickListener(this)
            x3.setOnClickListener(this)
            xy.setOnClickListener(this)
            ex.setOnClickListener(this)
            tenx.setOnClickListener(this)
            x1.setOnClickListener(this)
            rt2.setOnClickListener(this)
            rt3.setOnClickListener(this)
            rty.setOnClickListener(this)
            log.setOnClickListener(this)
            pi.setOnClickListener(this)
        }

        // listeners
        ac.setOnClickListener(this)
        plusmin.setOnClickListener(this)
        percent.setOnClickListener(this)
        div.setOnClickListener(this)
        seven.setOnClickListener(this)
        eight.setOnClickListener(this)
        nine.setOnClickListener(this)
        mult.setOnClickListener(this)
        four.setOnClickListener(this)
        five.setOnClickListener(this)
        six.setOnClickListener(this)
        minus.setOnClickListener(this)
        one.setOnClickListener(this)
        two.setOnClickListener(this)
        three.setOnClickListener(this)
        plus.setOnClickListener(this)
        zero.setOnClickListener(this)
        decimal.setOnClickListener(this)
        equal.setOnClickListener(this)
    }

    override fun onClick(v : View?){
        when(v?.id){


            R.id.Equal ->{
                topTextView.text = "0"
            }
            R.id.AC -> {
                topTextView.text = "0"
            }
            R.id.PlusMinus ->{
                topTextView.append(plusmin.text)
            }
            R.id.PercentSign ->{
                topTextView.append(percent.text)
            }
            R.id.Divide ->{
                topTextView.append(div.text
                )            }
            R.id.Seven ->{
                topTextView.append(seven.text)
            }
            R.id.Eight ->{
                topTextView.append(eight.text)
            }
            R.id.Nine ->{
                topTextView.append(nine.text)
            }
            R.id.Multiply ->{
                topTextView.append(mult.text)
            }
            R.id.Four ->{
                topTextView.append(four.text)
            }
            R.id.Five ->{
                topTextView.append(five.text)
            }
            R.id.Six ->{
                topTextView.append(six.text)
            }
            R.id.Minus ->{
                topTextView.append(minus.text)
            }
            R.id.One ->{
                topTextView.append(one.text)
            }
            R.id.Two ->{
                topTextView.append(two.text)
            }
            R.id.Three ->{
                topTextView.append(three.text)
            }
            R.id.Plus ->{
                topTextView.append(plus.text)
            }
            R.id.Zero ->{
                topTextView.append(zero.text)
            }
            R.id.Decimal ->{
                topTextView.append(decimal.text)
            }
            R.id.par ->{
                topTextView.append(par.text)
            }
            R.id.rpar ->{
                topTextView.append(rpar.text)
            }
            R.id.mc ->{
                topTextView.append(mc.text)
            }
            R.id.mp ->{
                topTextView.append(mp.text)
            }
            R.id.mm ->{
                topTextView.append(mm.text)
            }
            R.id.mr ->{
                topTextView.append(mr.text)
            }
            R.id.ln ->{
                topTextView.append(ln.text)
            }
            R.id.xclam ->{
                topTextView.append(xclam.text)
            }
            R.id.sin ->{
                topTextView.append(sin.text)
            }
            R.id.cos ->{
                topTextView.append(cos.text)
            }
            R.id.tan ->{
                topTextView.append(tan.text)
            }
            R.id.e ->{
                topTextView.append(e.text)
            }
            R.id.EE ->{
                topTextView.append(ee.text)
            }
            R.id.Rad ->{
                topTextView.append(rad.text)
            }
            R.id.sinh ->{
                topTextView.append(sinh.text)
            }
            R.id.cosh ->{
                topTextView.append(cosh.text)
            }
            R.id.tanh ->{
                topTextView.append(tanh.text)
            }
            R.id.rand ->{
                topTextView.append(rand.text)
            }
            else ->{
                topTextView.append("#")
            }
        }
    }
}