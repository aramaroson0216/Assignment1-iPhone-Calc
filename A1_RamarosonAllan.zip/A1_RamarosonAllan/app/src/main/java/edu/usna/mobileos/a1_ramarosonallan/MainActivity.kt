package edu.usna.mobileos.a1_ramarosonallan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var topTextView: TextView
    lateinit var ac : Button
    lateinit var plusmin : Button
    lateinit var div : Button
    lateinit var percent : Button
    lateinit var seven : Button
    lateinit var eight : Button
    lateinit var nine : Button
    lateinit var mult : Button
    lateinit var four : Button
    lateinit var five : Button
    lateinit var six : Button
    lateinit var minus : Button
    lateinit var one : Button
    lateinit var two : Button
    lateinit var three : Button
    lateinit var plus : Button
    lateinit var zero : Button
    lateinit var decimal : Button
    lateinit var equal : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        topTextView = findViewById(R.id.TopText)

        // buttons
        ac = findViewById(R.id.AC)
        plusmin = findViewById(R.id.PlusMinus)
        percent = findViewById(R.id.PercentSign)
        div = findViewById(R.id.Divide)
        seven = findViewById(R.id.Seven)
        eight  = findViewById(R.id.Eight)
        nine = findViewById(R.id.Nine)
        mult = findViewById(R.id.Multiply)
        four = findViewById(R.id.Four)
        five = findViewById(R.id.Five)
        six = findViewById(R.id.Six)
        minus = findViewById(R.id.Minus)
        one = findViewById(R.id.One)
        two = findViewById(R.id.Two)
        three = findViewById(R.id.Three)
        plus = findViewById(R.id.Plus)
        zero = findViewById(R.id.Zero)
        decimal = findViewById(R.id.Decimal)
        equal = findViewById(R.id.Equal)

        // listeners
        ac.setOnClickListener(this)
        plusmin.setOnClickListener(this)
        percent.setOnClickListener(this)
        div.setOnClickListener(this)
        seven.setOnClickListener(this)
        eight.setOnClickListener(this)
        nine.setOnClickListener(this)
        mult.setOnClickListener(this)
        four.setOnClickListener(this)
        five.setOnClickListener(this)
        six.setOnClickListener(this)
        minus.setOnClickListener(this)
        one.setOnClickListener(this)
        two.setOnClickListener(this)
        three.setOnClickListener(this)
        plus.setOnClickListener(this)
        zero.setOnClickListener(this)
        decimal.setOnClickListener(this)
        equal.setOnClickListener(this)
    }

    override fun onClick(v : View?){
        when(v?.id){


            R.id.Equal ->{
                topTextView.text = "0"
            }
            R.id.AC -> {
                topTextView.text = "0"
            }
            R.id.PlusMinus ->{
                topTextView.append(plusmin.text)
            }
            R.id.PercentSign ->{
                topTextView.append(percent.text)
            }
            R.id.Divide ->{
                topTextView.append(div.text
                )            }
            R.id.Seven ->{
                topTextView.append(seven.text)
            }
            R.id.Eight ->{
                topTextView.append(eight.text)
            }
            R.id.Nine ->{
                topTextView.append(nine.text)
            }
            R.id.Multiply ->{
                topTextView.append(mult.text)
            }
            R.id.Four ->{
                topTextView.append(four.text)
            }
            R.id.Five ->{
                topTextView.append(five.text)
            }
            R.id.Six ->{
                topTextView.append(six.text)
            }
            R.id.Minus ->{
                topTextView.append(minus.text)
            }
            R.id.One ->{
                topTextView.append(one.text)
            }
            R.id.Two ->{
                topTextView.append(two.text)
            }
            R.id.Three ->{
                topTextView.append(three.text)
            }
            R.id.Plus ->{
                topTextView.append(plus.text)
            }
            R.id.Zero ->{
                topTextView.append(zero.text)
            }
            R.id.Decimal ->{
                topTextView.append(decimal.text)
            }
        }
    }
}